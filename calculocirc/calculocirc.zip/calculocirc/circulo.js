var PI = Math.PI;

exports.area = function (r){
    return PI * r * r;
};

exports.circunferencia = function (r){
    return 2 * PI * r;
};

