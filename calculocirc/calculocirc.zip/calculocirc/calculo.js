var circulo = require('./circulo.js');
var http=require('http');
http.createServer(function(rec,res){
    res.end('um circulo de raio 4 tem area '+ circulo.area(4))
}).listen(8181);
